# CraveKart — full-stack food delivery starter

A colourful, responsive food-delivery experience with playful 3D CSS motion, category filters, search, cart controls, checkout form, and an Express API.

## Requirements
- Node.js 18+
- npm

## Run locally
Open two terminals:

**Terminal 1 — API**
```bash
cd server
npm install
npm run dev
```
API runs at `http://localhost:4000`.

**Terminal 2 — frontend**
```bash
cd client
npm install
npm run dev
```
Open the Vite URL printed in the terminal (usually `http://localhost:5173`).

The Vite dev server proxies `/api` requests to Express. Orders are stored in memory for this demo and reset when the API restarts. For production, connect a persistent database, authentication, payment provider, delivery/restaurant integrations, validation, and deployment secrets.
