import express from 'express';
import cors from 'cors';
const app=express(); const PORT=process.env.PORT||4000;
app.use(cors()); app.use(express.json({limit:'1mb'}));
const foods=[
{id:1,name:'Smash Burger',restaurant:'Bun Theory',price:249,rating:4.9,time:'20–25 min',category:'Burgers',emoji:'🍔',tag:'BESTSELLER',color:'#ffe0b2',desc:'Double smash patty, melty cheese, house sauce'},
{id:2,name:'Creamy Alfredo',restaurant:'Pasta Social',price:289,rating:4.8,time:'25–30 min',category:'Italian',emoji:'🍝',tag:'CHEF’S PICK',color:'#f8d8e7',desc:'Silky parmesan cream, herbs & roasted garlic'},
{id:3,name:'Rainbow Sushi',restaurant:'Maki House',price:359,rating:4.9,time:'30–35 min',category:'Asian',emoji:'🍣',tag:'FRESH DAILY',color:'#d9edcf',desc:'Colourful salmon, avocado and crunchy cucumber'},
{id:4,name:'Loaded Nachos',restaurant:'Mucho Mex',price:219,rating:4.7,time:'15–20 min',category:'Mexican',emoji:'🌮',tag:'SPICY FAV',color:'#ffe8a8',desc:'Crunchy nachos, salsa, jalapeño & creamy queso'},
{id:5,name:'Berry Pancakes',restaurant:'Sunny Side Up',price:199,rating:4.8,time:'20–25 min',category:'Desserts',emoji:'🥞',tag:'SWEET TREAT',color:'#e8dcff',desc:'Fluffy stacks, fresh berries and maple drizzle'},
{id:6,name:'Garden Pizza',restaurant:'Slice Society',price:329,rating:4.6,time:'25–30 min',category:'Italian',emoji:'🍕',tag:'WOOD FIRED',color:'#ffd6ca',desc:'Mozzarella, basil, cherry tomatoes & olive oil'},
{id:7,name:'Crispy Bao',restaurant:'Wok This Way',price:179,rating:4.7,time:'15–20 min',category:'Asian',emoji:'🥟',tag:'TRENDING',color:'#d8f0f0',desc:'Soft bao, crispy filling and tangy sesame glaze'},
{id:8,name:'Choco Lava',restaurant:'Sugar Rush',price:149,rating:4.9,time:'15–20 min',category:'Desserts',emoji:'🍫',tag:'MELTY MAGIC',color:'#f5d8c4',desc:'Warm chocolate cake with a gooey centre'}
];
const orders=[];
app.get('/api/health',(req,res)=>res.json({status:'ok',service:'CraveKart API'}));
app.get('/api/foods',(req,res)=>{const {category,q}=req.query;let result=foods;if(category&&category!=='All eats')result=result.filter(f=>f.category.toLowerCase()===String(category).toLowerCase());if(q)result=result.filter(f=>`${f.name} ${f.restaurant} ${f.category}`.toLowerCase().includes(String(q).toLowerCase()));res.json(result)});
app.get('/api/orders',(req,res)=>res.json(orders.map(({id,status,total,address,createdAt})=>({id,status,total,address,createdAt}))));
app.post('/api/orders',(req,res)=>{const {items,address,total}=req.body||{};if(!Array.isArray(items)||items.length===0)return res.status(400).json({error:'Add at least one item to your basket.'});if(!address||typeof address!=='string'||address.trim().length<4)return res.status(400).json({error:'Enter a valid delivery address.'});const normalized=[];for(const item of items){const product=foods.find(f=>f.id===Number(item.foodId));const quantity=Number(item.quantity);if(!product||!Number.isInteger(quantity)||quantity<1||quantity>30)return res.status(400).json({error:'One or more basket items are invalid.'});normalized.push({foodId:product.id,name:product.name,quantity,unitPrice:product.price,lineTotal:product.price*quantity})}const subtotal=normalized.reduce((s,i)=>s+i.lineTotal,0);const order={id:`CK${Date.now().toString().slice(-8)}`,status:'received',items:normalized,address:address.trim(),subtotal,deliveryFee:29,total:subtotal+29,createdAt:new Date().toISOString()};orders.unshift(order);res.status(201).json(order)});
app.use((req,res)=>res.status(404).json({error:'Route not found'}));
app.listen(PORT,()=>console.log(`CraveKart API running at http://localhost:${PORT}`));
